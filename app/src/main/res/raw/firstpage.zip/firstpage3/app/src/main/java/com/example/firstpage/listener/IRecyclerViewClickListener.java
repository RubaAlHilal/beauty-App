package com.example.firstpage.listener;

import android.view.View;

public interface IRecyclerViewClickListener {
    void onRecyclerClick(View view, int position);
}
