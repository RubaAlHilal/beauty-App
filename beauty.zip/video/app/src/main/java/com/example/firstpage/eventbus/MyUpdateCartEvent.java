package com.example.firstpage.eventbus;

public class MyUpdateCartEvent {
}
